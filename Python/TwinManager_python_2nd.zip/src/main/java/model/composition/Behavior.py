

class Behavior: {
	String name
	String type
	String fileLocation
	Object model # FMU
	
	def __init__(self, ) {
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def setName(self, String name) {
		this.name = name
	}
	
	def getType(self, ) {
		return this.type
	}
	
	def setType(self, String type) {
		this.type = type
	}
	
	def getFileLocation(self, ) {
		return this.fileLocation
	}
	
	def setFileLocation(self, String fileLocation) {
		this.fileLocation = fileLocation
	}
	
	def getModel(self, ) {
		return this.model
	}
	
	def setModel(self, Object model) {
		this.model = model
	}

}
