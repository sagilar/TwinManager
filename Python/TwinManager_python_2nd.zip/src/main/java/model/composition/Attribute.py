

class Attribute: {
	String name
	String type
	Object value
	
	def __init__(self, ) {
		value = new Object()
	}
	
	def __init__(self, String attrName, Object value) {
		this.name = attrName
		this.value = value
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def setName(self, String name) {
		this.name = name
	}
	
	def setValue(self, Object value) {
		this.value = value
	}
	
	def getValue(self, ) {
		return this.value
	}
}
