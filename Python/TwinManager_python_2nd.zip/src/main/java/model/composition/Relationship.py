

class Relationship: {
	String name
	Object fromObject
	Object toObject
	Object value
	String valueString

	
	def __init__(self, ) {
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def setName(self, String name) {
		this.name = name
	}
	
	def getFromObject(self, ) {
		return this.fromObject
	}
	
	def setFromObject(self, Object fromObject) {
		this.fromObject = fromObject
	}
	
	def getToObject(self, ) {
		return this.toObject
	}
	
	def setToObject(self, Object toObject) {
		this.toObject = toObject
	}
	
	def getValue(self, ) {
		return this.value
	}
	
	def setValue(self, Object value) {
		this.value = value
	}
	
	def getValueString(self, ) {
		return this.valueString
	}
	
	def setValueString(self, String valueString) {
		this.valueString = valueString
	}

}
