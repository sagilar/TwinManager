

# import java.util.ArrayList (Convert manually if needed)
# import java.util.List (Convert manually if needed)

# import model.composition.Operation (Convert manually if needed)

class Task: extends Operation implements Cloneable {
	List<Skill> skills = new ArrayList<Skill>()
	String name
    

	def __init__(self, ) {

	}
	
	def getName(self, ) {
		return this.name
	}
	
	def setName(self, String name) {
		this.name = name
	}

	public List<Skill> getSkills() {
		return this.skills
	}
	
	def addSkill(self, Skill sk) {
		Skill newSk = null
		try {
			newSk = (Skill) sk.clone()
			this.skills.add(newSk)
		} catch (CloneNotSupportedException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
			print("Error adding skill")
		}
	}
	
	def removeSkill(self, int i) {
		this.skills.remove(i)
	}
	
	def removeSkills(self, ) {
		this.skills.clear()
	}
	
	def executeTask(self, ) {
		print("Executing task")
		for (Skill skill : this.skills) {
			skill.executeSkill()
		}
	}
	
	def executeTask(self, int timeOutMillis) {
		print("Executing task")
		for (Skill skill : this.skills) {
			skill.executeSkill(timeOutMillis)
		}
	}

	@Override
	def clone(self, ) throws CloneNotSupportedException {
		return super.clone()
	}

}
