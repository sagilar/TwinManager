

# import java.util.ArrayList (Convert manually if needed)
# import java.util.List (Convert manually if needed)

# import model.composition.Operation (Convert manually if needed)

class DevicePrimitive:  extends Operation implements Cloneable {
	List<Object> params = new ArrayList<Object>()
	String name

	def __init__(self, ) {
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def setName(self, String name) {
		this.name = name
	}
	
	def setParams(self, List<Object> args) {
		this.params = args
	}
	
	public List<Object> getParams(){
		return this.params
	}
	
	def getParam(self, int i) {
		return this.params.get(i)
	}
	
	def clearParams(self, ) {
		this.params.clear()
	}
	
	def removeParam(self, int i) {
		this.params.remove(i)
	}
	
	@Override
	def clone(self, ) throws CloneNotSupportedException {
		Object obj = super.clone()
		
		List<Object> newParams = new ArrayList<Object>()
		DevicePrimitive newDP = (DevicePrimitive) obj
		
		for (Object p : this.params) {
			newParams.add(p)
		}
		newDP.setParams(newParams)
		return newDP
	}
}
