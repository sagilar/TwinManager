

# import java.util.ArrayList (Convert manually if needed)
# import java.util.List (Convert manually if needed)

# import model.composition.Operation (Convert manually if needed)

class Skill: extends Operation implements Cloneable {
	List<DevicePrimitive> devicePrimitives = new ArrayList<DevicePrimitive>()
	String name

	def __init__(self, ) {
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def setName(self, String name) {
		this.name = name
	}
	
	public List<DevicePrimitive> getDevicePrimitives() {
		return this.devicePrimitives
	}
	
	def setDevicePrimitives(self, List<DevicePrimitive> dps) {
		this.devicePrimitives = dps
	}
	
	def addDevicePrimitive(self, DevicePrimitive dp) {
		DevicePrimitive newDp = null
		try {
			newDp = (DevicePrimitive) dp.clone()
			this.devicePrimitives.add(newDp)
		} catch (CloneNotSupportedException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
			print("Error adding devprim")
		}
	}
	
	def removeDevicePrimitive(self, int i) {
		this.devicePrimitives.remove(i)
	}
	
	def removeDevicePrimitives(self, ) {
		this.devicePrimitives.clear()
	}
	
	def executeSkill(self, ) {
		print("Executing skill")
		for (DevicePrimitive dp : this.devicePrimitives) {
			dp.executeOperation(dp.params)
		}
	}
	
	def executeSkill(self, int timeOutMillis) {
		print("Executing skill")
		for (DevicePrimitive dp : this.devicePrimitives) {
			dp.executeOperation(dp.params)
			waitTime(timeOutMillis)
		}
	}
	
	def waitTime(self, int milliseconds) {
		try {
			Thread.sleep(milliseconds)
		} catch (InterruptedException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
	}
	
	@Override
	def clone(self, ) throws CloneNotSupportedException {
		Object obj = super.clone()
		
		List<DevicePrimitive> newListDp = new ArrayList<DevicePrimitive>()
		Skill newSkill = (Skill) obj
		
		for (DevicePrimitive dp : this.devicePrimitives) {
			newListDp.add(dp)
		}
		newSkill.setDevicePrimitives(newListDp)
		
		return newSkill
	}
}
