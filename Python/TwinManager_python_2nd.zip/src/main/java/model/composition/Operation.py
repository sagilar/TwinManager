

# import java.util.List (Convert manually if needed)

class Operation: {
	String name
	List<String> parameters
	
	def __init__(self, ) {
	}
	
	def setName(self, String name) {
		this.name = name
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def executeOperation(self, List<?> arguments) {
		# to be updated: callback
		return true
	}

}
