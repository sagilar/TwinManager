

class Parameter: {

	String name
	String value

	def __init__(self, ){}
	
	def __init__(self, String name, String value) {
		this.name = name
		this.value = value
	}
	
	def getName(self, ) {
		return this.name
	}
	
	def getValue(self, ) {
		return this.value
	}
}
