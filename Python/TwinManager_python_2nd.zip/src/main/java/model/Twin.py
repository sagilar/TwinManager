

# import model.TwinSchema (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)
# import model.composition.Operation (Convert manually if needed)

# import java.util.ArrayList (Convert manually if needed)
# import java.util.HashMap (Convert manually if needed)
# import java.util.LinkedList (Convert manually if needed)
# import java.util.List (Convert manually if needed)
# import java.util.Map (Convert manually if needed)

# import config.TwinConfiguration (Convert manually if needed)
# import endpoints.Endpoint (Convert manually if needed)
# import endpoints.MQTTEndpoint (Convert manually if needed)
# import endpoints.RabbitMQEndpoint (Convert manually if needed)
# import endpoints.FMIEndpoint (Convert manually if needed)


class Twin: {
	public Map<String,Attribute> attributes
	public Map<String,Operation> operations
	private TwinConfiguration config
	private String name
	private Endpoint endpoint
	private Clock clock
	private TwinSchema schema
	

	/***** Constructors *****/
	def __init__(self, String name, TwinSchema definition){
		this.attributes = new HashMap<String,Attribute>()
		this.operations = new HashMap<String,Operation>()
		this.name = name
		this.schema = definition
		this.clock = new Clock()
		this.registerAttributes(this.schema.getAttributes())
		this.registerOperations(this.schema.getOperations())
	}
	
	def __init__(self, String name, TwinConfiguration config) {
		this.name = name
		this.config = config
		this.attributes = new HashMap<String,Attribute>()
		this.operations = new HashMap<String,Operation>()
		this.clock = new Clock()
		
		if (config.conf.hasPath("rabbitmq")) {
			this.endpoint = new RabbitMQEndpoint(name,config)
		} else if (config.conf.hasPath("mqtt")) {
			this.endpoint = new MQTTEndpoint(name,config)
		} else if (config.conf.hasPath("fmi")){
			this.endpoint = new FMIEndpoint(name,config)
			List<Double> args = new ArrayList<Double>()
			args.add(0.0)
			this.endpoint.executeOperation("initializeSimulation",args)
		} else if(config.conf.hasPath("henshin")) {}
	}
	
	def __init__(self, String name, TwinSchema definition, TwinConfiguration config) {
		this.name = name
		this.config = config
		this.attributes = new HashMap<String,Attribute>()
		this.operations = new HashMap<String,Operation>()
		this.schema = definition
		this.clock = new Clock()
		
		
		if (config.conf.hasPath("rabbitmq")) {
			this.endpoint = new RabbitMQEndpoint(name,config)
		} else if (config.conf.hasPath("mqtt")) {
			this.endpoint = new MQTTEndpoint(name,config)
		} else if (config.conf.hasPath("fmi")){
			this.endpoint = new FMIEndpoint(name,config)
			List<Double> args = new ArrayList<Double>()
			args.add(0.0)
			this.endpoint.executeOperation("initializeSimulation",args)
		} else if(config.conf.hasPath("henshin")) {}
		this.registerAttributes(this.schema.getAttributes())
		this.registerOperations(this.schema.getOperations())
	}
	
	
	
	/***** Standard interface methods *****/

	def getAttributeValue(self, String attrName) {
		if (this.endpoint instanceof RabbitMQEndpoint) {
			Attribute attr = new Attribute()
			try {
				attr = this.endpoint.getAttributeValue(attrName)
				if (attr == null) {
					attr = new Attribute(attrName, null)
				}
				this.attributes.put(attrName, attr)
			} catch(Exception e) {}
		} else if(this.endpoint instanceof MQTTEndpoint) {
			Attribute attr = new Attribute()
			try {
				attr = this.endpoint.getAttributeValue(attrName)
				if (attr == null) {
					attr = new Attribute(attrName, null)
				}
				this.attributes.put(attrName, attr)
			} catch(Exception e) {}
			
		}
		else if(this.endpoint instanceof FMIEndpoint) {
			Attribute attr = this.endpoint.getAttributeValue(attrName)
			try {
				if (attr == null) {
					attr = new Attribute(attrName, null)
				}
				this.attributes.put(attrName,attr)
			} catch(Exception e) {}
		}
		return this.getAttribute(attrName)		
	}
	
	
	
	def setAttributeValue(self, String attrName, Attribute attr) {
		this.attributes.put(attrName,attr)
		if (this.endpoint instanceof RabbitMQEndpoint) {
			this.endpoint.setAttributeValue(attrName, attr)	
		} else if (this.endpoint instanceof MQTTEndpoint) {
			this.endpoint.setAttributeValue(attrName, attr)
		}		
		else if (this.endpoint instanceof FMIEndpoint) {
			this.endpoint.setAttributeValue(attrName, attr)
		}
		return true
	}
	
	

	def executeOperation(self, String opName, List<?> arguments) {
		if (this.endpoint instanceof RabbitMQEndpoint) {
			if (arguments == null) {
				this.endpoint.executeOperation(opName, null)
			}else {
				this.endpoint.executeOperation(opName, arguments)
			}
		} else if (this.endpoint instanceof MQTTEndpoint) {
			if (arguments == null) {
				this.endpoint.executeOperation(opName, null)
			}else {
				this.endpoint.executeOperation(opName, arguments)
			}
		} else if(this.endpoint instanceof FMIEndpoint) {
			this.endpoint.executeOperation(opName, arguments)
		}
		return true
	}
	
	/**** Time-based methods *****/
	
	def getAttributeValue(self, String attrName, Clock clock) {
		this.endpoint.setClock(clock)
		this.setClock(clock)
		if (this.endpoint instanceof RabbitMQEndpoint) {
			Attribute attr = new Attribute()
			try {
				attr = this.endpoint.getAttributeValue(attrName, clock)
				if (attr == null) {
					attr = new Attribute(attrName, null)
				}
				this.attributes.put(attrName, attr)
			} catch(Exception e) {}
		} else if(this.endpoint instanceof MQTTEndpoint) {
			Attribute attr = new Attribute()
			try {
				attr = this.endpoint.getAttributeValue(attrName, clock)
				if (attr == null) {
					attr = new Attribute(attrName, null)
				}
				this.attributes.put(attrName, attr)
			} catch(Exception e) {}
			
		}
		else if(this.endpoint instanceof FMIEndpoint) {
			Attribute attr = this.endpoint.getAttributeValue(attrName, clock)
			try {
				if (attr == null) {
					attr = new Attribute(attrName, null)
				}
				this.attributes.put(attrName,attr)
			} catch(Exception e) {}
		}
		return this.getAttribute(attrName)	
	}
	
	def setAttributeValue(self, String attrName, Attribute attr, Clock clock) {
		this.endpoint.setClock(clock)
		this.setClock(clock)
		this.attributes.put(attrName, attr)
		if (this.endpoint instanceof RabbitMQEndpoint) {
			this.endpoint.setAttributeValue(attrName, attr, clock)	
		} else if (this.endpoint instanceof MQTTEndpoint) {
			this.endpoint.setAttributeValue(attrName, attr, clock)
		}		
		else if (this.endpoint instanceof FMIEndpoint) {
			this.endpoint.setAttributeValue(attrName, attr, clock)
		}
		return true
	}
	
	def executeOperation(self, String opName, List<?> arguments, Clock clock) {
		this.endpoint.setClock(clock)
		this.setClock(clock)
		if (this.endpoint instanceof RabbitMQEndpoint) {
			if (arguments == null) {
				this.endpoint.executeOperation(opName, null, clock)
			}else {
				this.endpoint.executeOperation(opName, arguments, clock)
			}
		} else if (this.endpoint instanceof MQTTEndpoint) {
			if (arguments == null) {
				this.endpoint.executeOperation(opName, null, clock)
			}else {
				this.endpoint.executeOperation(opName, arguments, clock)
			}
		} else if(this.endpoint instanceof FMIEndpoint) {
			this.endpoint.executeOperation(opName, arguments, clock)
		}
		return true	
	}
	
	/***** Auxiliary methods *****/	
	
	def getName(self, ) {
		return name
	}
	
	def getEndpoint(self, ) {
		return this.endpoint
	}
	
	def setEndpoint(self, Endpoint endpoint) {
		this.endpoint = endpoint
	}
	
	public Map<String,Attribute> getAttributes(){
		return this.attributes
	}
	
	def getAttribute(self, String attrName){
		return this.attributes.get(attrName)
	}
	
	public Map<String,Operation> getOperations(){
		return this.operations
	}
	
	def getSchema(self, ) {
		return this.schema
	}
	
	def getConfiguration(self, ) {
		return this.config
	}

	def getEmptyClone(self, ) {
		Twin result = new Twin(this.name, this.config)
		return result
	}

	def registerOperations(self, List<Operation> operations) {
		for (Operation op : operations) {
			this.operations.put(op.getName(), new Operation())
			try {
				this.endpoint.registerOperation(this.name,op)
			} catch (Exception e) {}			
		}
	}
	
	def registerAttributes(self, List<Attribute> attributes) {
		for (Attribute attr : attributes) {
			this.attributes.put(attr.getName(), attr)
			try {
				this.endpoint.registerAttribute(attr.getName(),this.getAttribute(attr.getName()))
			} catch (Exception e) {}			 
		}		
		
	}

	def getTime(self, ) {
		return this.clock
	}

	def setClock(self, Clock clock) {
		this.clock = clock
	}





}
