

# import java.io.IOException (Convert manually if needed)
# import java.util.ArrayList (Convert manually if needed)
# import java.util.Collection (Convert manually if needed)
# import java.util.List (Convert manually if needed)
# import java.util.Map (Convert manually if needed)
# import java.util.Set (Convert manually if needed)

# import javax.xml.parsers.ParserConfigurationException (Convert manually if needed)

# import org.eclipse.basyx.aas.factory.aasx.AASXToMetamodelConverter (Convert manually if needed)
# import org.eclipse.basyx.aas.metamodel.api.IAssetAdministrationShell (Convert manually if needed)
# import org.apache.poi.openxml4j.exceptions.InvalidFormatException (Convert manually if needed)
# import org.eclipse.basyx.aas.bundle.AASBundle (Convert manually if needed)
# import org.eclipse.basyx.submodel.metamodel.api.ISubmodel (Convert manually if needed)
# import org.eclipse.basyx.submodel.metamodel.api.submodelelement.ISubmodelElement (Convert manually if needed)
# import org.xml.sax.SAXException (Convert manually if needed)

# import model.composition.Attribute (Convert manually if needed)
# import model.composition.Operation (Convert manually if needed)

class TwinSchema: {
	# TO DO: INITIALIZATION FROM JSON and XML
	private String className
	private List<Attribute> attributes
	private List<Operation> operations
	
	def __init__(self, ) {
	}
	
	def __init__(self, String className) {
		this.className = className
	}	
	
	public List<Attribute> getAttributes(){
		return this.attributes
	}
	
	public List<Operation> getOperations(){
		return this.operations
	}
	
	public static TwinSchema initializeFromAASX(String filePath, String aasIdShort) {
		TwinSchema schema = new TwinSchema()
		schema.attributes = new ArrayList<Attribute>()
		schema.operations = new ArrayList<Operation>()
		
		
		AASXToMetamodelConverter packageManager = new AASXToMetamodelConverter(filePath)
		Set<AASBundle> bundles = null
		try {
			bundles = packageManager.retrieveAASBundles()
		} catch (InvalidFormatException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (IOException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (ParserConfigurationException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (SAXException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
		/*AASBundle bundle = findBundle(bundles, aasIdShort)
		IAssetAdministrationShell objectAAS = bundle.getAAS()
		Map<String, ISubmodel> submodels = objectAAS.getSubmodels()
		ISubmodel operationalDataSubmodel = submodels.get("OperationalData")*/
		ISubmodel operationalDataSubmodel = findSubmodel(bundles,"OperationalData")
		
		ISubmodelElement seOperations = operationalDataSubmodel.getSubmodelElement("Operations")
		Collection<ISubmodelElement> seOperationsCollection = (Collection<ISubmodelElement>) seOperations.getValue()
		for (ISubmodelElement op : seOperationsCollection) {
			Operation twinOperation = new Operation()
			twinOperation.setName(op.getIdShort())
			schema.operations.add(twinOperation)
		}
		
		ISubmodelElement seVariables = operationalDataSubmodel.getSubmodelElement("Variables")
		Collection<ISubmodelElement> seVariablesCollection = (Collection<ISubmodelElement>) seVariables.getValue()
		for (ISubmodelElement attr : seVariablesCollection) {
			Attribute twinAttribute = new Attribute()
			twinAttribute.setName(attr.getIdShort())
			schema.attributes.add(twinAttribute)
		}
		return schema
	}
	

	private static ISubmodel findSubmodel(Set<AASBundle> bundles, String idShort) {
		for (AASBundle aasBundle : bundles) {
			for (ISubmodel sm : aasBundle.getSubmodels()) {
				if(sm.getIdShort().equals(idShort)) {
					return sm
				}
			}
		}
		return null
	}
	
	private static AASBundle findBundle(Set<AASBundle> bundles, String aasIdShort) {
		for (AASBundle aasBundle : bundles) {
			if (aasBundle.getAAS().getIdShort().equals(aasIdShort)) {
				return aasBundle
			}
		}
		return null
	}
	
	private static ISubmodel getBundleSubmodel(Set<ISubmodel> submodels, String submodelIdShort) {
		for (ISubmodel submodel : submodels) {
			if (submodel.getIdShort().equals(submodelIdShort))
				return submodel
		}
		return null
	}

}
