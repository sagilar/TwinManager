

# import java.util.ArrayList (Convert manually if needed)
# import java.util.List (Convert manually if needed)
# import java.util.Map (Convert manually if needed)
# import java.util.Map.Entry (Convert manually if needed)
# import java.util.Set (Convert manually if needed)


# import com.typesafe.config.Config (Convert manually if needed)
# import com.typesafe.config.ConfigValue (Convert manually if needed)

# import config.TwinSystemConfiguration (Convert manually if needed)
# import endpoints.AggregateEndpoint (Convert manually if needed)
# import endpoints.MaestroEndpoint (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)
# import model.Clock (Convert manually if needed)

class TwinSystem: {
	Map<String,Twin> twins
	TwinSystemConfiguration config
	String coeFilename
	AggregateEndpoint endpoint
	String systemName
	String outputPath
	Clock clock
	
	/***** For Physical Twin Systems *****/
	def __init__(self, String systemName, Map<String,Twin> twins) {
		this.twins = twins
		this.systemName = systemName
		this.clock = new Clock()
	}
	
	/***** For Digital Twin Systems *****/
	def __init__(self, String systemName, Map<String,Twin> twins,TwinSystemConfiguration config, String coeFilename, String outputPath) {
		this.twins = twins
		this.config = config
		this.coeFilename = coeFilename
		this.systemName = systemName
		this.outputPath = outputPath
		this.endpoint = new MaestroEndpoint(this.systemName,this.config,this.coeFilename,this.outputPath)
		this.setConnections()
		this.clock = new Clock()
	}
	
	/***** Standard interface methods *****/
	
	def executeOperation(self, String opName, List<?> arguments, String twinName) {
		# No Endpoint
		this.twins.get(twinName).executeOperation(opName, arguments)
		return true		
	}
	
	def executeOperation(self, String opName, List<?> arguments) {
		# Maestro Endpoint
		try {
			this.endpoint.executeOperation(opName, arguments)
			return true
		}catch(Exception e) {
			return false
		}
		
	}
	
	def setAttributeValue(self, String attrName, Attribute attr) {
		if (this.endpoint != null) {
			this.endpoint.setAttributeValue(attrName,attr)
		} else {
			# Nothing happens
		}
		return true
	}
	
	def setAttributeValue(self, String attrName, Attribute attr, String twinName) {
		this.twins.get(twinName).attributes.put(attrName, attr)
		if (this.endpoint != null) {
			this.endpoint.setAttributeValue(attrName, attr, twinName)
		}
		return true
	}
	
	def setAttributeValues(self, List<String> attrNames, List<Attribute> attrs) {
		if (this.endpoint != null) {
			this.endpoint.setAttributeValues(attrNames, attrs)
		} else {
			# Nothing happens
		}
		return true
	}
	
	def getAttributeValue(self, String attrName) {
		if (this.endpoint != null) {
			Attribute attr = this.endpoint.getAttributeValue(attrName)
			return attr
		} else {
			return new Attribute()
		}
		
	}
	
	def getAttributeValue(self, String attrName, String twinName) {
		if (this.endpoint != null) {
			Attribute value = this.endpoint.getAttributeValue(attrName, twinName)
			this.twins.get(twinName).attributes.put(attrName, value)
			return value
		} else {
			return this.twins.get(twinName).getAttributeValue(attrName)
		}
	}
	
	
	
	public List<Attribute> getAttributeValues(List<String> attrNames) {
		if (this.endpoint != null) {
			return this.endpoint.getAttributeValues(attrNames)
		} else {
			# Nothing happens
			return new ArrayList<Attribute>()
		}
	}
	
	/**** Time-based methods *****/
	
	def executeOperation(self, String opName, List<?> arguments, String twinName, Clock clock) {
		this.setClock(clock)
		Twin twin = this.twins.get(twinName)
		twin.setClock(clock)
		return twin.executeOperation(opName, arguments, clock)	
	}
	
	def executeOperation(self, String opName, List<?> arguments, Clock clock) {
		this.setClock(clock)
		
		try {
			this.endpoint.setClock(clock)
			this.endpoint.executeOperation(opName, arguments,clock)
			return true
		}catch(Exception e) {
			return false
		}	
	}
	
	def getAttributeValue(self, String attrName, Clock clock) {
		if (this.endpoint != null) {
			return this.endpoint.getAttributeValue(attrName, clock)
		} else {
			return new Attribute()
		}
	}
	
	def getAttributeValue(self, String attrName, String twinName, Clock clock) {
		if (this.endpoint != null) {
			Attribute attr = this.endpoint.getAttributeValue(attrName, twinName, clock)
			this.twins.get(twinName).attributes.put(attrName, attr)
			return attr
		} else {
			Twin twin = this.twins.get(twinName)
			twin.setClock(clock)
			return twin.getAttributeValue(attrName, clock)
		}
	}
	
	def setAttributeValue(self, String attrName, Attribute attr, Clock clock) {
		this.setClock(clock)
		if (this.endpoint != null) {
			this.endpoint.setClock(clock)
			this.endpoint.setAttributeValue(attrName, attr, clock)
		} 
		return true
	}
	
	def setAttributeValue(self, String attrName, Attribute attr, String twinName, Clock clock) {
		this.setClock(clock)
		if (this.endpoint != null) {
			this.endpoint.setClock(clock)
			this.endpoint.setAttributeValue(attrName, attr,twinName, clock)
		} else {
			Twin twin = this.twins.get(twinName)
			twin.setClock(clock)
			twin.setAttributeValue(attrName, attr, clock)
		}
		return true
	}
	
	/***** Auxiliary methods *****/	
	
	def setConnections(self, ) {
		String input = ""
		String output = ""
		Config innerConf = this.config.conf.getConfig("connections")
		Set<Entry<String, ConfigValue>> entries = innerConf.root().entrySet()

		for (Map.Entry<String, ConfigValue> entry: entries) {
			input = entry.getKey()
		    output = entry.getValue().render()
		}
	}
	
	def mapAlias(self, String in) {
		String out = ""
		try {
			out = this.config.conf.getString("aliases." + in)
		}catch(Exception e) {
			out = in
		}
		return out
	}
	
	def validate(self, ) {
		return true
	}
	
	def synchronize(self, ) {
		
	}
	
	def setClock(self, Clock clock) {
		this.clock = clock
	}
	
	def getClock(self, ) {
		return this.clock
	}

}
