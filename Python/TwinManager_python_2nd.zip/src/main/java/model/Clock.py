

class Clock: {
	private int now = 0
	
	def increaseTime(self, int amount) {
		this.now += amount
	}
	
	def getNow(self, ) {
		return this.now
	}
	
	def setClock(self, int value) {
		this.now = value
	}

}

