

# import java.util.List (Convert manually if needed)

# import config.TwinSystemConfiguration (Convert manually if needed)
# import model.Clock (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)

public interface AggregateEndpoint extends Endpoint{
	TwinSystemConfiguration twinSystemConfig = null
	
	def getAttributeValue(self, String attrName, String twinName)
	
	def getAttributeValue(self, String attrName, String twinName, Clock clock)	

	def setAttributeValue(self, String attrName, Attribute attr, String twinName)
	
	def setAttributeValue(self, String attrName, Attribute attr, String twinName, Clock clock)
	
	def executeOperation(self, String opName, List<?> arguments, String twinName)
	
	def executeOperation(self, String opName, List<?> arguments, String twinName, Clock clock)
}
