

# import java.io.File (Convert manually if needed)
# import java.io.FileNotFoundException (Convert manually if needed)
# import java.io.IOException (Convert manually if needed)
# import java.util.ArrayList (Convert manually if needed)
# import java.util.HashMap (Convert manually if needed)
# import java.util.List (Convert manually if needed)
# import java.util.Map (Convert manually if needed)
# import org.javafmi.wrapper.Simulation (Convert manually if needed)

# import config.TwinConfiguration (Convert manually if needed)
# import model.Clock (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)
# import model.composition.Operation (Convert manually if needed)


class FMIEndpoint: implements IndividualEndpoint {
	
	public String twinName = ""
	private double stepSize = 0.0
	private TwinConfiguration twinConfig
	private String fmuPath
	
	public Simulation simulation
	private Map<String,Attribute> registeredAttributes
	private Map<String,Operation> registeredOperations
	private Clock clock
	
	def __init__(self, String twinName, TwinConfiguration config) {
		this.twinName = twinName
		this.twinConfig = config
		this.fmuPath = config.conf.getString("fmi.file_path")
		this.stepSize = config.conf.getDouble("fmi.step_size")
		this.simulation = new Simulation(this.fmuPath)
		this.clock = new Clock()
		
		this.registeredAttributes = new HashMap<String,Attribute>()
		this.registeredOperations = new HashMap<String,Operation>()
	}
	
	public List<Attribute> getAttributeValues(List<String> variables) {
		Object value = new Object()
		Attribute attr = new Attribute()
		List<Attribute> attrs = new ArrayList<Attribute>()
		for(String var : variables) {
			value = simulation.read(var).asDouble()
			attr.setName(var)
			attr.setValue(value)
			attrs.add(attr)
		}
		return attrs
	}
	
	def getAttributeValue(self, String variable) {
		String variableAlias = mapAlias(variable)
		Attribute tmpAttr = new Attribute()
		tmpAttr.setName(variable)		
		Object value = simulation.read(variableAlias).asDouble()
		tmpAttr.setValue(value)
		return tmpAttr
	}
	
	def setAttributeValues(self, List<String> variables,List<Attribute> attrs) {		
		for(String var : variables) {
			int index = variables.indexOf(var)
			String mappedVariable = mapAlias(var)
			simulation.write(mappedVariable).with(Double.valueOf(attrs.get(index).getValue().toString()))
		}
		return true
	}
	
	def setAttributeValue(self, String variable,Attribute attr) {
		String mappedVariable = mapAlias(variable)
		simulation.write(mappedVariable).with(Double.valueOf(attr.getValue().toString()))
		return true
	}
	
	def initializeSimulation(self, double startTime) {
		this.simulation.init(startTime)
	}
	
	def terminateSimulation(self, ) {
		this.simulation.terminate()
	}
	
	def doStep(self, double stepSize) {
		this.simulation.doStep(stepSize)
	}
	
	def mapAlias(self, String in) {
		String out = ""
		try {
			out = this.twinConfig.conf.getString("fmi.aliases." + in)
		}catch(Exception e) {
			out = in
		}		
		return out
	}

	
	def registerOperation(self, String name, Operation op) {
		this.registeredOperations.put(name,op)		
	}

	
	def registerAttribute(self, String name, Attribute attr) {
		this.registeredAttributes.put(name,attr)
	}

	
	def executeOperation(self, String opName, List<?> arguments) {
		if (opName.equals("doStep")) {
			if(arguments == null) {
				
			}else {
				this.stepSize = (double) arguments.get(0)
				if (arguments.size() > 1) {
					Map<String,Object> args = (Map<String, Object>) arguments.get(1)
					for (Map.Entry<String, Object> entry : args.entrySet()) {
						Attribute tmpAttr = new Attribute()
						tmpAttr.setName(entry.getKey())
						tmpAttr.setValue(entry.getValue())
						this.setAttributeValue(entry.getKey(), tmpAttr)
					}
				}
			}
			this.doStep(this.stepSize)
		} else if(opName.equals("terminateSimulation")) {
			this.terminateSimulation()
		} else if(opName.equals("initializeSimulation")) {
			double startTime = (double) arguments.get(0)
			this.initializeSimulation(startTime)
		}
		return true
	}
	
	def setClock(self, Clock value) {
		this.clock = value
		
	}
	
	def getClock(self, ) {
		return this.clock
	}
	
	def getTwinName(self, ) {
		return twinName
	}
	
	@Override
	def getAttributeValue(self, String attrName, Clock clock) {
		this.setClock(clock)
		return this.getAttributeValue(attrName)
	}

	@Override
	def setAttributeValue(self, String attrName, Attribute attr, Clock clock) {
		this.setClock(clock)
		return this.setAttributeValue(attrName, attr)
	}

	@Override
	def executeOperation(self, String opName, List<?> arguments, Clock clock) {
		this.setClock(clock)
		return this.executeOperation(opName, arguments)
	}
	
}
