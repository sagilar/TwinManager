


# import java.util.ArrayList (Convert manually if needed)
# import java.util.Arrays (Convert manually if needed)
# import java.util.HashMap (Convert manually if needed)
# import java.util.List (Convert manually if needed)
# import java.util.Map (Convert manually if needed)
# import java.util.Iterator (Convert manually if needed)
# import java.util.concurrent.TimeoutException (Convert manually if needed)
# import org.json.JSONObject (Convert manually if needed)

# import com.fasterxml.jackson.databind.ObjectWriter (Convert manually if needed)
# import com.opencsv.CSVReader (Convert manually if needed)
# import com.opencsv.CSVReaderBuilder (Convert manually if needed)
# import com.opencsv.exceptions.CsvException (Convert manually if needed)
# import com.rabbitmq.client.Channel (Convert manually if needed)
# import com.rabbitmq.client.Connection (Convert manually if needed)
# import com.rabbitmq.client.ConnectionFactory (Convert manually if needed)
# import com.rabbitmq.client.DeliverCallback (Convert manually if needed)
# import com.typesafe.config.Config (Convert manually if needed)
# import com.typesafe.config.ConfigFactory (Convert manually if needed)
# import com.typesafe.config.ConfigRenderOptions (Convert manually if needed)
# import org.json.JSONObject (Convert manually if needed)

# import config.TwinSystemConfiguration (Convert manually if needed)
# import model.Clock (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)
# import model.composition.Operation (Convert manually if needed)

# import java.io.File (Convert manually if needed)
# import java.io.FileNotFoundException (Convert manually if needed)
# import java.io.FileReader (Convert manually if needed)
# import java.io.FileWriter (Convert manually if needed)
# import java.io.IOException (Convert manually if needed)
# import java.nio.file.Paths (Convert manually if needed)
# import java.time.ZoneOffset (Convert manually if needed)
# import java.time.ZonedDateTime (Convert manually if needed)
# import java.time.format.DateTimeFormatter (Convert manually if needed)

class MaestroEndpoint: implements AggregateEndpoint {

	private String twinSystemName
	private double stepSize = 0.0
	private double finalTime = 0.0
	private double startTime = 0.0
	private TwinSystemConfiguration systemConfig
	private Config coeConfig
	private String outputPath
	String coeFilename = "coe.json"
	String simulationFilename
	# Data processing
	private CSVReader reader
	private String[] columnNames
	List<String> columnList
	private List<String[]> myEntries
	private Clock clock = new Clock()
	private String lastCommand = "simulate"
	
	#RabbitMQ
	boolean rabbitMQEnabled = false
	boolean flagSend = false
	String ip
	int port
	String username
	String password
	String exchange
	String type
	String vhost
	String routingKeyFromCosim
	String routingKeyToCosim
	String rmqMessageFromCosim = ""
	String rmqMessageToCosim = ""
	ConnectionFactory factory
	Connection conn
	Channel channelFromCosim
	Channel channelToCosim
	DeliverCallback deliverCallbackFromCosim
	DeliverCallback deliverCallbackToCosim
	private Map<String,Object> registeredAttributes
	private Map<String,Operation> registeredOperations
	
	def getTwinSystemName(self, ) {
		return twinSystemName
	}
	
	def __init__(self, String twinSystemName, TwinSystemConfiguration config,String coeFilename, String outputPath)
	{
		#This one is the one to be used
		this.twinSystemName = twinSystemName
		this.coeFilename = coeFilename
		File file = new File(coeFilename)   
		this.coeConfig = ConfigFactory.parseFile(file)
		this.outputPath = outputPath
		this.systemConfig = config
		this.simulationFilename = this.systemConfig.conf.origin().filename()
		this.stepSize = this.systemConfig.conf.getDouble("algorithm.size")
		#this.finalTime = this.systemConfig.conf.getDouble("endTime")
		#this.startTime = this.systemConfig.conf.getDouble("startTime")
		this.registeredAttributes = new HashMap<String,Object>()		
		this.registeredOperations = new HashMap<String,Operation>()
		
		/***** If RabbitMQFMU is enabled *****/
		if (this.systemConfig.conf.hasPath("rabbitmq")) {
			#print("RabbitMQ enabled")
			this.rabbitMQEnabled = true
			this.ip = this.systemConfig.conf.getString("rabbitmq.ip")
			this.port = this.systemConfig.conf.getInt("rabbitmq.port")
			this.username = this.systemConfig.conf.getString("rabbitmq.username")
			this.password = this.systemConfig.conf.getString("rabbitmq.password")
			this.exchange = this.systemConfig.conf.getString("rabbitmq.exchange")
			this.type = this.systemConfig.conf.getString("rabbitmq.type")
			this.vhost = this.systemConfig.conf.getString("rabbitmq.vhost")
			this.routingKeyFromCosim = this.systemConfig.conf.getString("rabbitmq.routing_key_from_cosim")
			this.routingKeyToCosim = this.systemConfig.conf.getString("rabbitmq.routing_key_to_cosim")
			
			
			this.deliverCallbackFromCosim = (consumerTagFrom, deliveryFrom) -> {
				this.rmqMessageFromCosim = new String(deliveryFrom.getBody(), "UTF-8")
				String keyStart = "waiting for input data for simulation"
				if (this.rmqMessageFromCosim.contains(keyStart)) {
					this.flagSend = true
					/* Execute the publishing after this message has been received */
				}
				try{
					JSONObject jsonObject = new JSONObject(this.rmqMessageFromCosim)
					Iterator<String> keys = jsonObject.keys()
					while(keys.hasNext()) {
						String key = keys.next()
						if (jsonObject.get(key) instanceof JSONObject) {
							Attribute tmpAttr = new Attribute()
							tmpAttr.setName(key)
							tmpAttr.setValue(jsonObject.get(key))
							registeredAttributes.put(key, tmpAttr)
							String alias = mapAlias(key)
							Attribute tmpAttrAlias = new Attribute()
							tmpAttrAlias.setName(alias)
							tmpAttrAlias.setValue(jsonObject.get(key))
							registeredAttributes.put(alias, tmpAttrAlias)
						}
					}
				}catch (Exception e){

				}
				
			}

			this.deliverCallbackToCosim = (consumerTagTo, deliveryTo) -> {
				this.rmqMessageToCosim = new String(deliveryTo.getBody(), "UTF-8")
			}
			
			this.factory = new ConnectionFactory()
			if (this.password.equals("")){
				
			}else {
				this.factory.setUsername(this.username)
				this.factory.setPassword(this.password)
			}
			#this.factory.setVirtualHost(this.vhost)
			this.factory.setHost(this.ip)
			this.factory.setPort(this.port)

			try {
				this.conn = this.factory.newConnection()
				this.channelFromCosim = this.conn.createChannel()
				this.channelFromCosim.exchangeDeclare(this.exchange,"direct")
				String queueNameFromCosim = this.channelFromCosim.queueDeclare().getQueue()
				this.channelFromCosim.queueBind(queueNameFromCosim, this.exchange, this.routingKeyFromCosim)				
				this.channelFromCosim.basicConsume(queueNameFromCosim, this.deliverCallbackFromCosim, consumerTagFrom -> { })
				this.channelToCosim = this.conn.createChannel()
				this.channelToCosim.exchangeDeclare(this.exchange,"direct")
				String queueNameToCosim = this.channelToCosim.queueDeclare().getQueue()
				this.channelToCosim.queueBind(queueNameToCosim, this.exchange, this.routingKeyToCosim)
				this.channelToCosim.basicConsume(queueNameToCosim, this.deliverCallbackToCosim, consumerTagTo -> { })
			} catch (IOException e) {
				# TODO Auto-generated catch block
				e.printStackTrace()
			} catch (TimeoutException e) {
				# TODO Auto-generated catch block
				e.printStackTrace()
			}
			
		}
		
		
		
	}

	
	def registerOperation(self, String name, Operation op) {
		#Only relevant when RabbitMQFMU is in use
		#name = RabbitMQFMU variable
		this.registeredOperations.put(name,op)
	}

	
	def registerAttribute(self, String name, Attribute attr) {
		#Only relevant when RabbitMQFMU is in use
		#name = RabbitMQFMU variable
		this.registeredAttributes.put(name,attr)
		/*
		String queue = name + ":queue"
		try {
			channel.queueDeclare(queue, false, true, false, null)
		} catch (IOException e1) {
			e1.printStackTrace()
		}
		try {
			channel.queueBind(queue, this.routingKey, this.routingKey)
		} catch (IOException e) {
			e.printStackTrace()
		}
		
		
		this.deliverCallback = (consumerTag, delivery) -> {
			for (Map.Entry<String, Object> entry : this.registeredAttributes.entrySet()) {
				try {
					final String message = new String(delivery.getBody(), "UTF-8")
			        JSONObject jsonMessage = new JSONObject(message)
			        String alias = mapAlias(entry.getKey())
			        Object value = jsonMessage.getJSONObject("fields").get(alias)
			        entry.setValue(value)
				} catch (Exception e) {
				}
			}
      	}
      	try {
      		channel.basicConsume(queue, true, this.deliverCallback, consumerTag -> {})
		} catch (IOException e) {
			e.printStackTrace()
		}
		*/
	}

	
	public List<Attribute> getAttributeValues(List<String> variables) {
		# from the csv output file
		List<Attribute> attrs = new ArrayList<Attribute>()
		for (String var : variables) {
			Attribute attr = this.getAttributeValue(var)
			attrs.add(attr)
		}
		return attrs
	}

	
	def getAttributeValue(self, String variable) {
		# from the csv output file
		String[] entry = myEntries.get(1)
		if (this.lastCommand.equals("simulate")) {
			entry = myEntries.get(this.clock.getNow() + 1)
		}else if(this.lastCommand.equals("doStep")) {
			entry = myEntries.get(2)
		}
		List<String> entryList = Arrays.asList(entry)
		Object value = null
		Attribute attr = new Attribute()
	    for (String column : this.columnList) {
	    	if(variable.equals(column)) {
	    		int i = this.columnList.indexOf(column)
	    		value =  (Object)(entryList.get(i))
	    	}
	    }
	    attr.setName(variable)
	    attr.setValue(value)
		return attr
	}
	
	def getAttributeValue(self, String variable, String twinName) {
		# from the csv output file
		String twinRaw = mapAlias(twinName)
		String varRaw = mapAlias(variable)
		String composedRaw = twinRaw + "." + varRaw
		String[] entry = myEntries.get(1)
		if (this.lastCommand.equals("simulate")) {
			entry = myEntries.get(this.clock.getNow() + 1)
		}else if(this.lastCommand.equals("doStep")) {
			entry = myEntries.get(2)
		}
		List<String> entryList = Arrays.asList(entry)
		Object value = null
		Attribute attr = new Attribute()
	    for (String column : this.columnList) {
	    	if(composedRaw.equals(column)) {
	    		int i = this.columnList.indexOf(column)
	    		value =  (Object)(entryList.get(i))
	    	}
	    }
	    attr.setName(variable)
	    attr.setValue(value)
		return attr
	}
	
	def getAttributeValue(self, String variable, Clock clock) {
		# from the csv output file
		String[] entry = myEntries.get(clock.getNow())
		List<String> entryList = Arrays.asList(entry)
		Object value = null
		Attribute attr = new Attribute()
	    for (String column : this.columnList) {
	    	if(variable.equals(column)) {
	    		int i = this.columnList.indexOf(column)
	    		value =  (Object)(entryList.get(i))
	    	}
	    }
	    attr.setName(variable)
	    attr.setValue(value)
		return attr
	}
	
	def getAttributeValue(self, String variable, String twinName, Clock clock) {
		# from the csv output file
		String twinRaw = mapAlias(twinName)
		String varRaw = mapAlias(variable)
		String composedRaw = twinRaw + "." + varRaw
		String[] entry = myEntries.get(clock.getNow())
		List<String> entryList = Arrays.asList(entry)
		Object value = null
		Attribute attr = new Attribute()
	    for (String column : this.columnList) {
	    	if(composedRaw.equals(column)) {
	    		int i = this.columnList.indexOf(column)
	    		value =  (Object)(entryList.get(i))
	    	}
	    }
	    attr.setName(variable)
	    attr.setValue(value)
		return attr
	}
	
	
	def setAttributeValues(self, List<String> variables, List<Attribute> attrs) {
		if(this.rabbitMQEnabled) {
			Map<String,String> body = new HashMap<String,String>()
			String ts = ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ISO_INSTANT)
			body.put("time", ts)
			for (int i=0 i<variables.size()i++) {				
				body.put(variables.get(i), attrs.get(i).getValue().toString())				
			}
			JSONObject bodyJSON = new JSONObject(body)
			String bodyMessage = bodyJSON.toString()
			this.rawSend(bodyMessage)	
		}else {
			# On the multimodel.json file
			for (String var : variables) {
				int index = variables.indexOf(var)
				this.setAttributeValue(var, attrs.get(index))
			}
		}
		return true		
	}

	
	def setAttributeValue(self, String variable, Attribute attr) {
		if(this.rabbitMQEnabled) {
			Map<String,String> body = new HashMap<String,String>()
			String ts = ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ISO_INSTANT)
			body.put("time", ts)
			body.put(variable, attr.getValue().toString())
			JSONObject bodyJSON = new JSONObject(body)
			String bodyMessage = bodyJSON.toString()
			this.rawSend(bodyMessage)
		}else {
			# On the multimodel.json file
			String fileString = this.systemConfig.conf.root().render(ConfigRenderOptions.concise().setFormatted(true).setJson(true))
			JSONObject completeJsonObject = new JSONObject(fileString)
			if (variable.equals("step_size") || variable.equals("stepSize")) {
				JSONObject innerjsonObject = new JSONObject(fileString).getJSONObject("algorithm")
				innerjsonObject.put("size",attr.getValue())
				completeJsonObject.put("algorithm", innerjsonObject)
				try (FileWriter file = new FileWriter(this.simulationFilename)) 
		        {
		            file.write(completeJsonObject.toString(4))
		            file.close()
		        } catch (IOException e) {
					# TODO Auto-generated catch block
					e.printStackTrace()
				}
			}else {
				JSONObject innerjsonObject = new JSONObject(fileString).getJSONObject("parameters")
				innerjsonObject.put(variable,attr.getValue())
				completeJsonObject.put("parameters", innerjsonObject)
				try (FileWriter file = new FileWriter(this.simulationFilename)) 
		        {
		            file.write(completeJsonObject.toString(4))
		            file.close()
		            
		        } catch (IOException e) {
					# TODO Auto-generated catch block
					e.printStackTrace()
				}
			}
			this.systemConfig = new TwinSystemConfiguration(this.simulationFilename)
		}
		return true
	}
	
	def setAttributeValue(self, String variable, Attribute attr, String twinName) {
		if(this.rabbitMQEnabled) {
			Map<String,String> body = new HashMap<String,String>()
			String ts = ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ISO_INSTANT)
			body.put("time", ts)
			body.put(variable, attr.getValue().toString())
			JSONObject bodyJSON = new JSONObject(body)
			String bodyMessage = bodyJSON.toString()
			this.rawSend(bodyMessage)
			
		}else {
			# On the multimodel.json file
			String twinRaw = mapAlias(twinName)
			String varRaw = mapAlias(variable)
			String composedRaw = twinRaw + "." + varRaw
			String fileString = this.systemConfig.conf.root().render(ConfigRenderOptions.concise().setFormatted(true).setJson(true))
			JSONObject completeJsonObject = new JSONObject(fileString)
			if (variable.equals("step_size") || variable.equals("stepSize")) {
				JSONObject innerjsonObject = new JSONObject(fileString).getJSONObject("algorithm")
				innerjsonObject.put("size",attr.getValue())
				completeJsonObject.put("algorithm", innerjsonObject)
				try (FileWriter file = new FileWriter(this.simulationFilename)) 
		        {
		            file.write(completeJsonObject.toString(4))
		            file.close()
		        } catch (IOException e) {
					# TODO Auto-generated catch block
					e.printStackTrace()
				}
			}else {
				JSONObject innerjsonObject = new JSONObject(fileString).getJSONObject("parameters")
				innerjsonObject.put(composedRaw,attr.getValue())
				completeJsonObject.put("parameters", innerjsonObject)
				try (FileWriter file = new FileWriter(this.simulationFilename)) 
		        {
		            file.write(completeJsonObject.toString(4))
		            file.close()
		            
		        } catch (IOException e) {
					# TODO Auto-generated catch block
					e.printStackTrace()
				}
			}
			this.systemConfig = new TwinSystemConfiguration(this.simulationFilename)
		}
		return true
	}
	
	def simulate(self, ) {
		#with the arguments defined in coe.json and multimodel.json
		org.intocps.maestro.Main.argumentHandler(
				new String[]{"import","sg1",this.coeFilename,this.simulationFilename, "-output",this.outputPath})
		org.intocps.maestro.Main.argumentHandler(
                new String[]{"interpret", "--verbose", Paths.get(outputPath,"spec.mabl").toString(),"-output",this.outputPath})
		try {
			this.reader = new CSVReaderBuilder(new FileReader(Paths.get(outputPath,"outputs.csv").toString())).build()
			this.myEntries = this.reader.readAll()
			this.columnNames = this.myEntries.get(0)
			this.columnList = Arrays.asList(this.columnNames)
		} catch (FileNotFoundException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (IOException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (CsvException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
	}
	
	def simulate(self, double endTime) {
		#fixedEndtime
		String fileString = this.coeConfig.root().render(ConfigRenderOptions.concise().setFormatted(true).setJson(true))
		JSONObject jsonObject = new JSONObject(fileString)
		jsonObject.put("startTime",0.0)
		jsonObject.put("endTime",endTime)
		try (FileWriter file = new FileWriter(this.coeFilename)) 
        {
			#ObjectWriter writer = mapper.defaultPrettyPrintingWriter()
            file.write(jsonObject.toString(4))
            file.close()
            File fileRead = new File(this.coeFilename)   
            this.coeConfig = ConfigFactory.parseFile(fileRead)
            
        } catch (IOException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
		this.simulate()
	}
	
	def simulate(self, double startTime,double endTime) {
		#fixed endTime and fixed startTime
		String fileString = this.coeConfig.root().render(ConfigRenderOptions.concise().setFormatted(true).setJson(true))
		JSONObject jsonObject = new JSONObject(fileString)
		jsonObject.put("startTime",startTime)
		jsonObject.put("endTime",endTime)
		try (FileWriter file = new FileWriter(this.coeFilename)) 
        {
            file.write(jsonObject.toString(4))
            file.close()
            File fileRead = new File(this.coeFilename)
            this.coeConfig = ConfigFactory.parseFile(fileRead)
            
        } catch (IOException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
		this.simulate()
	}
	
	def doStep(self, ) {
		this.simulate(0.0,this.stepSize*2)
	}
	


	
	def executeOperation(self, String opName, List<?> arguments) {
		if (opName.equals("simulate")) {
			this.lastCommand = "simulate"
			if(arguments == null) {
				
			}else {
				this.stepSize = (double) arguments.get(0)
				if (arguments.size() > 1) {
					
					Map<String,Object> args = (Map<String, Object>) arguments.get(1)
					for (Map.Entry<String, Object> entry : args.entrySet()) {
						Attribute tmpAttr = new Attribute()
						tmpAttr.setName(entry.getKey())
						tmpAttr.setValue(entry.getValue())
					    this.setAttributeValue(entry.getKey(), tmpAttr)
					}
				}
			}
			this.simulate()
		}else if(opName.equals("doStep")) {
			this.lastCommand = "doStep"
			if(arguments == null) {
				
			}else {
				this.stepSize = (double) arguments.get(0)
				if (arguments.size() > 1) {
					Map<String,Object> args = (Map<String, Object>) arguments.get(1)
					for (Map.Entry<String, Object> entry : args.entrySet()) {
						Attribute tmpAttr = new Attribute()
						tmpAttr.setName(entry.getKey())
						tmpAttr.setValue(entry.getValue())
						this.setAttributeValue(entry.getKey(), tmpAttr)
					}
				}
			}
			this.doStep()
		}
		return true
	}
	
	def setClock(self, Clock value) {
		this.clock = value
	}
	
	
	def getClock(self, ) {
		return this.clock
	}
	
	def mapAlias(self, String in) {
		String out = ""
		try {
			out = this.systemConfig.conf.getString("aliases." + in)
		}catch(Exception e) {
			out = in
		}
		
		return out
	}
	
	@Override
	def setAttributeValue(self, String attrName, Attribute attr, Clock clock) {
		this.setClock(clock)
		return this.setAttributeValue(attrName, attr)
	}

	@Override
	def executeOperation(self, String opName, List<?> arguments, Clock clock) {
		this.setClock(clock)
		return this.executeOperation(opName, arguments)
	}

	@Override
	def setAttributeValue(self, String attrName, Attribute attr, String twinName, Clock clock) {
		this.setClock(clock)
		return this.setAttributeValue(attrName, attr, twinName)
	}
	
	/***** RabbitMQFMU support *****/
	def rawSend(self, String message) {
		if (this.flagSend == true) {
			try {
				this.channelToCosim.basicPublish(this.exchange, this.routingKeyToCosim, null, message.getBytes())
			} catch (IOException e) {
				e.printStackTrace()
			}
		}
		
	}

	@Override
	def executeOperation(self, String opName, List<?> arguments, String twinName) {
		# Not Applicable
		return false
	}

	@Override
	def executeOperation(self, String opName, List<?> arguments, String twinName, Clock clock) {
		# Not Applicable
		return false
	}

	

}
