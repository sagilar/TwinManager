


# import java.util.HashMap (Convert manually if needed)
# import java.util.List (Convert manually if needed)

# import config.TwinConfiguration (Convert manually if needed)
# import model.Clock (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)
# import model.composition.Operation (Convert manually if needed)


public interface Endpoint {	
	
	public Clock clock = null

	def registerOperation(self, String name, Operation op)

	def registerAttribute(self, String name, Attribute attr)

	public List<Attribute> getAttributeValues(List<String> variables)
	
	def getAttributeValue(self, String variable)
	
	def getAttributeValue(self, String attrName, Clock clock)
	
	def setAttributeValues(self, List<String> variables,List<Attribute> attributes)
	
	def setAttributeValue(self, String variable,Attribute attr)
	
	def setAttributeValue(self, String attrName,Attribute attr, Clock clock)
	
	def executeOperation(self, String opName, List<?> arguments)
	
	def executeOperation(self, String opName, List<?> arguments, Clock clock)

	def setClock(self, Clock clock)

	def getClock(self, )
	
}
