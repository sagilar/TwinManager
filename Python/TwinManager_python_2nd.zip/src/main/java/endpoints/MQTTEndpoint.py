

# import java.io.IOException (Convert manually if needed)
# import java.io.UnsupportedEncodingException (Convert manually if needed)
# import java.util.ArrayList (Convert manually if needed)
# import java.util.HashMap (Convert manually if needed)
# import java.util.List (Convert manually if needed)
# import java.util.Map (Convert manually if needed)

# import org.apache.commons.text.RandomStringGenerator (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.IMqttToken (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttCallback (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttClient (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttClientPersistence (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttConnectOptions (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttException (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttMessage (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttPersistenceException (Convert manually if needed)
# import org.eclipse.paho.client.mqttv3.MqttSecurityException (Convert manually if needed)
# import org.json.JSONObject (Convert manually if needed)

# import config.TwinConfiguration (Convert manually if needed)
# import model.Clock (Convert manually if needed)
# import model.composition.Attribute (Convert manually if needed)
# import model.composition.Operation (Convert manually if needed)


class MQTTEndpoint: implements IndividualEndpoint {
	String ip
	int port
	String username
	String password
	String topic
	TwinConfiguration twinConfig
	MqttClient mqttClient
	MqttCallback mqttCallback
	String twinName
	private Clock clock
	
	# Schema
	Map<String,Attribute> registeredAttributes
	Map<String,Operation> registeredOperations
	
	def __init__(self, String twinName, TwinConfiguration config) {
		this.twinName = twinName
		this.twinConfig = config
		this.ip = config.conf.getString("mqtt.ip")
		this.port = config.conf.getInt("mqtt.port")
		this.username = config.conf.getString("mqtt.username")
		this.password = config.conf.getString("mqtt.password")
		this.topic = config.conf.getString("mqtt.topic")
		String broker = "tcp:#" + ip + ":" + String.valueOf(port)
		this.clock = new Clock()

		this.registeredAttributes = new HashMap<String,Attribute>()		
		this.registeredOperations = new HashMap<String,Operation>()
		try {
			RandomStringGenerator generator = new RandomStringGenerator.Builder()
				     .withinRange('a', 'z').build()
			String randomLetters = generator.generate(20)
			this.mqttClient = new MqttClient(broker,randomLetters, null)
		} catch (MqttException e1) {
			# TODO Auto-generated catch block
			e1.printStackTrace()
		}
        MqttConnectOptions connOpts = new MqttConnectOptions()
        #connOpts.setCleanSession(true)
        if (!this.username.equals("")) {
        	connOpts.setUserName(this.username)
        	connOpts.setPassword(this.password.toCharArray())
        }
        try {
        	mqttClient.connectWithResult(connOpts)
        	#token.waitForCompletion()
			mqttClient.subscribe(this.topic + "#") #This registers all the attributes
		} catch (MqttSecurityException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (MqttException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
        
        this.mqttCallback = new MqttCallback() {

			@Override
			def connectionLost(self, Throwable cause) {
				# TODO Auto-generated method stub
				
			}

			@Override
			def messageArrived(self, String topic, MqttMessage message) throws Exception {
				processOncomingMessage(topic,message)				
			}

			@Override
			def deliveryComplete(self, IMqttDeliveryToken token) {
				# TODO Auto-generated method stub
				
			}
        	
        }
        this.mqttClient.setCallback(mqttCallback)
	}
	
	def processOncomingMessage(self, String topic, MqttMessage mqttMessage) {
		String message = ""
		String[] topicVar = topic.split("/")
		String variable = topicVar[topicVar.length-1]
		try {
			message = new String(mqttMessage.getPayload(), "UTF-8")
			
		} catch (UnsupportedEncodingException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
		Attribute tmpAttr = new Attribute()
		String alias = mapAlias(variable)
		tmpAttr.setName(alias)
		tmpAttr.setValue(message)
		this.registeredAttributes.put(alias, tmpAttr)
	}
	
	@Override
	def registerOperation(self, String name, Operation op) {
		# TODO Auto-generated method stub
		this.registeredOperations.put(name,op)
	}
	@Override
	def registerAttribute(self, String name, Attribute attr) {
		this.registeredAttributes.put(name,attr)
	}
	@Override
	public List<Attribute> getAttributeValues(List<String> variables) {
		List<Attribute> attrs = new ArrayList<Attribute>()
		for(String var : variables) {
			int index = variables.indexOf(var)
			Attribute attr = this.getAttributeValue(var)
			attrs.add(attr)
		}
		return attrs
	}
	@Override
	def getAttributeValue(self, String variable) {
		return this.registeredAttributes.get(variable)
	}
	@Override
	def setAttributeValues(self, List<String> variables, List<Attribute> attrs) {
		for(String var : variables) {
			int index = variables.indexOf(var)
			this.setAttributeValue(var, attrs.get(index))
		}
		return true
	}
	@Override
	def setAttributeValue(self, String variable, Attribute attr) {
		String topic = this.topic + variable
		String content = String.valueOf(attr.getValue())
		this.registeredAttributes.put(variable, attr)		
		MqttMessage message = new MqttMessage(content.getBytes())
		try {
			this.mqttClient.publish(topic, message)
		} catch (MqttPersistenceException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (MqttException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
		return true
	}
	@Override
	def executeOperation(self, String opName, List<?> arguments) {
		# TODO Auto-generated method stub
		String topic = this.topic + opName
		String content = ""
		boolean success = false
		for (Object arg: arguments) {
			content = content + String.valueOf(arg) + ","
		}
		content = "(" + content + ")".replace(",)", ")")		
		MqttMessage message = new MqttMessage(content.getBytes())
		try {
			this.mqttClient.publish(topic, message)
			success = true
		} catch (MqttPersistenceException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		} catch (MqttException e) {
			# TODO Auto-generated catch block
			e.printStackTrace()
		}
		return success
	}

	@Override
	def setClock(self, Clock clock) {
		this.clock = clock
	}

	@Override
	def getClock(self, ) {
		return this.clock
	}

	def mapAlias(self, String in) {
		String out = ""
		try {
			out = this.twinConfig.conf.getString("mqtt.aliases." + in)
		}catch(Exception e) {
			out = in
		}		
		return out
	}
	
	def getTwinName(self, ) {
		return twinName
	}
	
	@Override
	def getAttributeValue(self, String attrName, Clock clock) {
		this.setClock(clock)
		return this.getAttributeValue(attrName)
	}

	@Override
	def setAttributeValue(self, String attrName, Attribute attr, Clock clock) {
		this.setClock(clock)
		return this.setAttributeValue(attrName, attr)
	}

	@Override
	def executeOperation(self, String opName, List<?> arguments, Clock clock) {
		this.setClock(clock)
		return this.executeOperation(opName, arguments)
	}

}
