

# import config.TwinConfiguration (Convert manually if needed)

public interface IndividualEndpoint extends Endpoint {
	public TwinConfiguration config = null
	public String twinName = null
	def getTwinName(self, )
}
