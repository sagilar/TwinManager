


# import java.io.File (Convert manually if needed)

import com.typesafe.config.*

class TwinConfiguration: {
	public Config conf
	
	def __init__(self, String filename) {
		File file = new File(filename)   
		conf = ConfigFactory.parseFile(file)
	}
	
}
