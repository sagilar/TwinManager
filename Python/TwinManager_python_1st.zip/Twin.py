class Twin:
    pass
