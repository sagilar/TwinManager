class IndividualEndpoint:
    pass
