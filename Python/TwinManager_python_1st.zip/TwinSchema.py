class TwinSchema:
    pass
