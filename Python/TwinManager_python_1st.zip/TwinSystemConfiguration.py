class TwinSystemConfiguration:
    pass
