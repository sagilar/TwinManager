class DeviationChecker:
    pass
