class Clock:
    pass
