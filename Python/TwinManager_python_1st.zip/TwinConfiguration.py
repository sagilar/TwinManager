class TwinConfiguration:
    pass
