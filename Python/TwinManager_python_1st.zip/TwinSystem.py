class TwinSystem:
    pass
