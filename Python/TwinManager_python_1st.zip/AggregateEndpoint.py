class AggregateEndpoint:
    pass
