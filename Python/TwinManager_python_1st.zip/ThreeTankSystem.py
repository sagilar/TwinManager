class ThreeTankSystem:
    pass
