class Behavior:
    pass
