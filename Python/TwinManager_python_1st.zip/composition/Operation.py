class Operation:
    pass
