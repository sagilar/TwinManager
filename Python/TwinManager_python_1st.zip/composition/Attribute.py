class Attribute:
    pass
