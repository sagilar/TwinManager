class Skill:
    pass
