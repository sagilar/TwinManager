class DevicePrimitive:
    pass
