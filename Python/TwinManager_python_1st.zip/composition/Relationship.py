class Relationship:
    pass
