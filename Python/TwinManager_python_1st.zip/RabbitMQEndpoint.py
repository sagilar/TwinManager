class RabbitMQEndpoint:
    pass
