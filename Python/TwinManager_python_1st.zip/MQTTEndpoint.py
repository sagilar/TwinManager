class MQTTEndpoint:
    pass
