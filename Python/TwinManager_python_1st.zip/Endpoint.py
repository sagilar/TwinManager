class Endpoint:
    pass
