class FMIEndpoint:
    pass
